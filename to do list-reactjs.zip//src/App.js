import "./styles.css";

export default function App() {
  return (
    <div classname="Container">
      <h1 classname="title">to do list</h1>
      <input type="text" />
      <button>add</button> <br />
      <input type="text" />
    </div>
  );
}
